package constructer;

public class PARADEMO {

	public static void main(String[] args) {
		PARAMETER std1=new PARAMETER(2,"Alex");
		PARAMETER std2=new PARAMETER(10,"Annie");
		std1.display();
		std2.display();

	}
}