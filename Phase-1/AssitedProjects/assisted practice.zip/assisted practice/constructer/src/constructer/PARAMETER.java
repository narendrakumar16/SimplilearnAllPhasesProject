package constructer;
class PARAMETER{
	int id;
	String name;

	PARAMETER(int i,String n)
	{
	id=i;
	name=n;
	}

	void display() {
	System.out.println(id+" "+name);
	}
}
