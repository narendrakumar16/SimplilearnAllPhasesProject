package string;

public class STRING {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
