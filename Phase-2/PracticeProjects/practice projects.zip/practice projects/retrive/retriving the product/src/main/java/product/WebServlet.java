package product;

public @interface WebServlet {

}
